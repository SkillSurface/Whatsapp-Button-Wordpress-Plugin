/* Skill WhatsApp Chat Pro v3 — admin controller (jQuery + Bootstrap 5.3 + Chart.js). */
(function ($) {
  'use strict';
  var A = window.SWCP_ADMIN || {};
  var S = $.extend(true, {}, A.settings || {});
  var dirty = false, chart = null;
  var $root = $('.swcp-admin');

  function esc(s) { return $('<div>').text(s == null ? '' : String(s)).html(); }
  function digits(v) { return String(v || '').replace(/\D+/g, '').replace(/^0+/, ''); }
  function validPhone(v) { var d = digits(v); return d.length >= 7 && d.length <= 15; }
  function toast(msg, ok) {
    var el = document.getElementById('swcp-toast');
    el.className = 'toast align-items-center border-0 ' + (ok === false ? 'err' : 'ok');
    el.querySelector('.toast-body').textContent = msg;
    bootstrap.Toast.getOrCreateInstance(el, { delay: 3000 }).show();
  }
  function post(action, data) {
    return $.post(A.ajax, $.extend({ action: 'swcp_' + action, nonce: A.nonce }, data || {}));
  }
  function setDirty(v) { dirty = v; $('.swcp-dirty').toggleClass('d-none', !v); }

  /* ---------- Bind settings <-> fields ---------- */
  function fill() {
    $root.find('[data-key]').each(function () {
      var $f = $(this), k = $f.data('key'), v = S[k];
      if ($f.is(':checkbox')) $f.prop('checked', !!+v);
      else if ($f.is(':radio')) $f.prop('checked', $f.val() === v);
      else $f.val(v == null ? '' : v);
    });
    $root.find('[data-mirror]').each(function () { $(this).val(S[$(this).data('mirror')]); });
    $root.find('[data-out]').each(function () { $(this).text(S[$(this).data('out')] + ($(this).data('suffix') || 'px')); });
    $('.swcp-hours tr[data-day]').each(function () {
      var h = (S.hours || {})[$(this).data('day')] || {};
      $(this).find('[data-h=on]').prop('checked', !!+h.on);
      $(this).find('[data-h=from]').val(h.from); $(this).find('[data-h=to]').val(h.to);
    });
    renderAgents(); renderChips(); deps(); validate(); preview(); checklist();
  }

  function read($f) {
    var k = $f.data('key');
    if ($f.is(':checkbox')) S[k] = $f.is(':checked') ? 1 : 0;
    else if ($f.is(':radio')) { if ($f.is(':checked')) S[k] = $f.val(); }
    else if ($f.attr('type') === 'number' || $f.attr('type') === 'range') S[k] = parseInt($f.val(), 10) || 0;
    else S[k] = $f.val();
    $root.find('[data-key="' + k + '"]').not($f).each(function () { if ($(this).is(':checkbox')) $(this).prop('checked', !!S[k]); });
    $root.find('[data-mirror="' + k + '"]').val(S[k]);
    $root.find('[data-out="' + k + '"]').text(S[k] + ($root.find('[data-out="' + k + '"]').data('suffix') || 'px'));
  }

  $root.on('input change', '[data-key]', function () { read($(this)); setDirty(true); deps(); validate(); preview(); checklist(); });
  $root.on('input', '[data-mirror]', function () {
    var v = $(this).val(); if (/^#[0-9a-f]{6}$/i.test(v)) { var k = $(this).data('mirror'); S[k] = v; $('#f-' + k).val(v); setDirty(true); preview(); }
  });
  $root.on('change', '.swcp-hours input', function () {
    var $tr = $(this).closest('tr'), d = $tr.data('day');
    S.hours[d] = { on: $tr.find('[data-h=on]').is(':checked') ? 1 : 0, from: $tr.find('[data-h=from]').val(), to: $tr.find('[data-h=to]').val() };
    setDirty(true); preview();
  });
  $('.swcp-copy-mon').on('click', function () {
    ['tue', 'wed', 'thu', 'fri'].forEach(function (d) { S.hours[d] = $.extend({}, S.hours.mon); }); fill(); setDirty(true);
  });

  function deps() {
    $root.find('.swcp-dep').each(function () {
      var r = String($(this).data('dep')), neg = r.indexOf('!=') > -1, p = r.split(neg ? '!=' : '='), cur = String(S[p[0]]);
      $(this).toggleClass('d-none', neg ? cur === p[1] : cur !== p[1]);
    });
  }
  function validate() {
    var ok = !S.phone || validPhone(S.phone);
    $('#f-phone').toggleClass('is-invalid', !ok).toggleClass('is-valid', !!S.phone && ok);
    return ok;
  }

  /* ---------- Agents repeater ---------- */
  function agentHtml(a, i) {
    var ava = a.avatar ? '<img src="' + esc(a.avatar) + '" alt="">' : esc((a.name || 'A').charAt(0).toUpperCase());
    return '<div class="swcp-agent-card" draggable="true" data-i="' + i + '">' +
      '<div class="d-flex gap-3 align-items-start"><i class="bi bi-grip-vertical swcp-handle mt-2"></i>' +
      '<div class="swcp-agent-ava" title="Change avatar" data-act="avatar">' + ava + '</div>' +
      '<div class="flex-grow-1"><div class="row g-2">' +
      '<div class="col-md-6"><input class="form-control" data-a="name" placeholder="Name" value="' + esc(a.name) + '"></div>' +
      '<div class="col-md-6"><input class="form-control" data-a="role" placeholder="Role / department" value="' + esc(a.role) + '"></div>' +
      '<div class="col-md-6"><div class="input-group"><span class="input-group-text">+</span><input class="form-control' + (a.phone && !validPhone(a.phone) ? ' is-invalid' : '') + '" data-a="phone" inputmode="numeric" placeholder="923001234567" value="' + esc(a.phone) + '"></div></div>' +
      '<div class="col-md-6"><input class="form-control" data-a="message" placeholder="Custom pre-filled message (optional)" value="' + esc(a.message) + '"></div>' +
      '</div></div><div class="d-flex flex-column align-items-end gap-2">' +
      '<div class="form-check form-switch m-0"><input class="form-check-input" type="checkbox" data-a="active" ' + (+a.active ? 'checked' : '') + ' title="Active"></div>' +
      '<button type="button" class="btn btn-sm btn-outline-danger" data-act="del" title="Remove"><i class="bi bi-trash"></i></button></div></div></div>';
  }
  function renderAgents() {
    S.agents = S.agents || [];
    $('#swcp-agents').html(S.agents.map(agentHtml).join(''));
    $('#swcp-agents-empty').toggleClass('d-none', S.agents.length > 0);
    $('.swcp-add-agent').prop('disabled', S.agents.length >= 20);
  }
  $('.swcp-add-agent').on('click', function () {
    S.agents.push({ id: '', name: '', role: '', phone: '', avatar: '', message: '', active: 1 });
    renderAgents(); setDirty(true); $('#swcp-agents .swcp-agent-card:last [data-a=name]').trigger('focus');
  });
  $('#swcp-agents').on('input change', '[data-a]', function () {
    var i = $(this).closest('[data-i]').data('i'), k = $(this).data('a');
    S.agents[i][k] = $(this).is(':checkbox') ? ($(this).is(':checked') ? 1 : 0) : $(this).val();
    if (k === 'phone') $(this).toggleClass('is-invalid', !!S.agents[i].phone && !validPhone(S.agents[i].phone));
    setDirty(true); preview();
  }).on('click', '[data-act=del]', function () {
    S.agents.splice($(this).closest('[data-i]').data('i'), 1); renderAgents(); setDirty(true); preview();
  }).on('click', '[data-act=avatar]', function () {
    var i = $(this).closest('[data-i]').data('i');
    media(function (url) { S.agents[i].avatar = url; renderAgents(); setDirty(true); preview(); });
  });
  // Native drag & drop reorder
  var dragFrom = null;
  $('#swcp-agents').on('dragstart', '.swcp-agent-card', function () { dragFrom = $(this).data('i'); $(this).addClass('dragging'); })
    .on('dragend', '.swcp-agent-card', function () { $(this).removeClass('dragging'); })
    .on('dragover', '.swcp-agent-card', function (e) { e.preventDefault(); })
    .on('drop', '.swcp-agent-card', function (e) {
      e.preventDefault(); var to = $(this).data('i'); if (dragFrom === null || dragFrom === to) return;
      var m = S.agents.splice(dragFrom, 1)[0]; S.agents.splice(to, 0, m); dragFrom = null; renderAgents(); setDirty(true); preview();
    });

  /* ---------- Media library ---------- */
  function media(cb) {
    if (!window.wp || !wp.media) return;
    var f = wp.media({ title: 'Select image', library: { type: 'image' }, multiple: false });
    f.on('select', function () { cb(f.state().get('selection').first().toJSON().url); }); f.open();
  }
  $root.on('click', '.swcp-media', function () {
    var $t = $('#' + $(this).data('target')); media(function (url) { $t.val(url).trigger('change'); });
  });

  /* ---------- Color presets ---------- */
  var presets = [['WhatsApp', '#25D366', '#075E54'], ['Teal', '#128C7E', '#0b3d38'], ['Ocean', '#0ea5e9', '#075985'], ['Midnight', '#111827', '#1f2937'], ['Coral', '#f97316', '#9a3412'], ['Rose', '#e11d48', '#881337']];
  presets.forEach(function (p) {
    $('<button type="button" class="swcp-preset" title="' + p[0] + '"></button>').css('background', 'linear-gradient(135deg,' + p[1] + ' 50%,' + p[2] + ' 50%)')
      .on('click', function () { S.bg_color = p[1]; S.header_color = p[2]; fill(); setDirty(true); }).appendTo('#swcp-presets');
  });

  /* ---------- AJAX page search ---------- */
  var timer, chipCache = {};
  function ids() { return String(S.page_ids || '').split(',').filter(Boolean); }
  function renderChips() {
    var list = ids(); if (!list.length) { $('#swcp-chips').empty(); return; }
    var missing = list.filter(function (id) { return !chipCache[id]; });
    var draw = function () {
      $('#swcp-chips').html(list.map(function (id) {
        var c = chipCache[id] || { title: '#' + id, type: '' };
        return '<span class="swcp-chip">' + esc(c.title) + ' <small class="opacity-50">' + esc(c.type) + '</small><button type="button" data-rm="' + id + '" aria-label="Remove">&times;</button></span>';
      }).join(''));
    };
    draw();
    if (missing.length) post('search_pages', { ids: missing.join(',') }).done(function (r) { (r.data || []).forEach(function (p) { chipCache[p.id] = p; }); draw(); });
  }
  $('#swcp-page-search').on('input', function () {
    var q = $(this).val().trim(); clearTimeout(timer);
    if (q.length < 2) { $('#swcp-suggest').addClass('d-none'); return; }
    $('#swcp-suggest').removeClass('d-none').html('<div class="list-group-item small text-body-secondary"><span class="spinner-border spinner-border-sm me-2"></span>Searching…</div>');
    timer = setTimeout(function () {
      post('search_pages', { q: q }).done(function (r) {
        var rows = (r.data || []).map(function (p) { chipCache[p.id] = p; return '<button type="button" class="list-group-item list-group-item-action d-flex justify-content-between" data-add="' + p.id + '"><span>' + esc(p.title) + '</span><span class="badge text-bg-light">' + esc(p.type) + '</span></button>'; });
        $('#swcp-suggest').html(rows.join('') || '<div class="list-group-item small text-body-secondary">No results</div>');
      });
    }, 300);
  });
  $(document).on('click', '[data-add]', function () {
    var l = ids(), id = String($(this).data('add')); if (l.indexOf(id) < 0) l.push(id);
    S.page_ids = l.join(','); $('#swcp-page-search').val(''); $('#swcp-suggest').addClass('d-none'); renderChips(); setDirty(true);
  }).on('click', '[data-rm]', function () {
    var id = String($(this).data('rm')); S.page_ids = ids().filter(function (x) { return x !== id; }).join(','); renderChips(); setDirty(true);
  }).on('click', function (e) { if (!$(e.target).closest('#swcp-page-search,#swcp-suggest').length) $('#swcp-suggest').addClass('d-none'); });

  /* ---------- Live preview (uses real frontend.css) ---------- */
  function preview() {
    var agents = (S.agents || []).filter(function (a) { return +a.active && validPhone(a.phone); });
    if (!agents.length) agents = [{ name: S.agent_name, role: S.agent_title, avatar: S.agent_avatar }];
    var single = agents.length === 1, a0 = agents[0];
    var icon = S.icon_style === 'custom' && S.custom_icon ? '<img src="' + esc(S.custom_icon) + '" alt="">' : (S.icon_style === 'outline' ? A.iconOut : A.icon);
    var wasOpen = $('#swcp-preview-host .swcp-popup').length && !$('#swcp-preview-host .swcp-popup').prop('hidden');
    var body = single
      ? '<div class="swcp-bubble"><span class="swcp-bubble-name">' + esc(a0.name) + '</span>' + esc(S.welcome_msg).replace(/\n/g, '<br>') + '<time>12:00</time></div>'
      : '<ul class="swcp-agents">' + agents.map(function (a) { return '<li><a class="swcp-agent" href="#"><span class="swcp-avatar">' + (a.avatar ? '<img src="' + esc(a.avatar) + '" alt="">' : esc((a.name || 'A').charAt(0).toUpperCase())) + '<i class="swcp-dot on"></i></span><span class="swcp-agent-meta"><strong>' + esc(a.name) + '</strong><small>' + esc(a.role) + '</small></span><span class="swcp-agent-go">' + A.icon + '</span></a></li>'; }).join('') + '</ul>';
    var popup = S.mode === 'popup' ? '<div class="swcp-popup"' + (wasOpen ? '' : ' hidden') + '><div class="swcp-head"><div class="swcp-head-icon">' + A.icon + '</div><div class="swcp-head-text"><strong>' + esc(single ? a0.name : S.popup_title) + '</strong><small>' + esc(single ? a0.role : S.popup_subtitle) + '</small></div><button type="button" class="swcp-close">&times;</button></div><div class="swcp-body">' + body + '</div><div class="swcp-foot">' +
      (+S.gdpr_enabled ? '<label class="swcp-gdpr"><input type="checkbox"> <span>' + esc(S.gdpr_text) + '</span></label>' : '') +
      (single ? '<a class="swcp-cta" href="#">' + A.icon + '<span>' + esc(S.cta_text) + '</span></a>' : '') + (S.footer_note ? '<p class="swcp-note">' + esc(S.footer_note) + '</p>' : '') + '</div></div>' : '';
    var css = '--swcp-bg:' + S.bg_color + ';--swcp-icon:' + S.icon_color + ';--swcp-header:' + S.header_color + ';--swcp-x:' + Math.min(S.offset_x, 40) + 'px;--swcp-y:' + Math.min(S.offset_y, 40) + 'px;--swcp-size:' + S.button_size + 'px;--swcp-z:5;';
    var html = '<div class="swcp-wrap swcp-' + S.position + ' swcp-theme-' + S.theme + ' swcp-shape-' + S.button_shape + ' swcp-anim-' + S.animation + (wasOpen ? ' swcp-is-open' : '') + (+S.enabled ? '' : ' opacity-50') + '" style="' + css + '">' + popup +
      (+S.show_button_text && S.button_text ? '<span class="swcp-tooltip" style="opacity:1;transform:none">' + esc(S.button_text) + '</span>' : '') +
      '<a class="swcp-btn" href="#"><span class="swcp-btn-icon">' + icon + '</span><span class="swcp-btn-close">&times;</span>' + (+S.notification_badge ? '<span class="swcp-badge">1</span>' : '') + '</a></div>';
    $('#swcp-preview-host').html(html);
  }
  $('#swcp-preview-host').on('click', '.swcp-btn, .swcp-close', function (e) {
    e.preventDefault(); var $p = $('#swcp-preview-host .swcp-popup'); if (!$p.length) return;
    var open = $p.prop('hidden'); $p.prop('hidden', !open); $('#swcp-preview-host .swcp-wrap').toggleClass('swcp-is-open', open);
  }).on('click', '.swcp-cta, .swcp-agent', function (e) { e.preventDefault(); });
  $('[data-device]').on('click', function () { $('[data-device]').removeClass('active'); $(this).addClass('active'); $('#swcp-stage').toggleClass('mobile', $(this).data('device') === 'mobile'); });

  /* ---------- Checklist ---------- */
  function checklist() {
    var hasAgent = (S.agents || []).some(function (a) { return +a.active && validPhone(a.phone); });
    var items = [
      [validPhone(S.phone) || hasAgent, 'Add a valid WhatsApp number or at least one active agent'],
      [!!+S.enabled, 'Widget is enabled'],
      [S.bg_color !== '#25D366' || S.header_color !== '#075E54', 'Customize colours to match your brand (optional)'],
      [!!+S.hours_enabled, 'Configure business hours (optional)'],
      [!!+S.analytics_enabled, 'Analytics enabled']
    ];
    $('#swcp-checklist').html(items.map(function (i) { return '<li><i class="bi ' + (i[0] ? 'bi-check-circle-fill' : 'bi-circle') + '"></i>' + esc(i[1]) + '</li>'; }).join(''));
  }

  /* ---------- Save / reset / import / export ---------- */
  function save() {
    if (!validate()) { bootstrap.Tab.getOrCreateInstance($('[data-tab=general]')[0]).show(); $('#f-phone').trigger('focus'); toast('Please fix the WhatsApp number.', false); return; }
    var $b = $('.swcp-save').prop('disabled', true); $b.find('.spinner-border').removeClass('d-none');
    post('save', { settings: JSON.stringify(S) }).done(function (r) {
      if (r && r.success) { S = r.data.settings; fill(); setDirty(false); toast(A.i18n.saved); } else toast((r.data && r.data.message) || A.i18n.error, false);
    }).fail(function () { toast(A.i18n.error, false); }).always(function () { $b.prop('disabled', false).find('.spinner-border').addClass('d-none'); });
  }
  $('.swcp-save').on('click', save);
  $(document).on('keydown', function (e) { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); save(); } });
  $('.swcp-reset').on('click', function () { if (!confirm(A.i18n.reset)) return; post('reset').done(function (r) { S = r.data.settings; fill(); setDirty(false); toast(A.i18n.saved); }); });
  $('.swcp-clear-stats').on('click', function () { if (!confirm(A.i18n.clear)) return; post('clear_stats').done(function () { stats(); toast('Analytics cleared.'); }); });
  $('.swcp-export').on('click', function () {
    var blob = new Blob([JSON.stringify(S, null, 2)], { type: 'application/json' }), url = URL.createObjectURL(blob), a = document.createElement('a');
    a.href = url; a.download = 'whatsapp-chat-pro-settings.json'; document.body.appendChild(a); a.click(); a.remove(); setTimeout(function () { URL.revokeObjectURL(url); }, 30000);
  });
  $('.swcp-import').on('change', function () {
    var f = this.files[0]; if (!f) return; var rd = new FileReader();
    rd.onload = function () {
      try { JSON.parse(rd.result); } catch (e) { toast('Invalid JSON file.', false); return; }
      post('import', { settings: rd.result }).done(function (r) { if (r.success) { S = r.data.settings; fill(); setDirty(false); toast('Settings imported.'); } else toast(r.data.message, false); });
    }; rd.readAsText(f); this.value = '';
  });
  $('.swcp-test').on('click', function () { if (!validPhone(S.phone)) { validate(); return; } window.open('https://wa.me/' + digits(S.phone) + '?text=' + encodeURIComponent('Test from WhatsApp Chat Pro'), '_blank', 'noopener'); });
  $root.on('click', '.swcp-copy', function () { var v = $('#' + $(this).data('copy')).val(); navigator.clipboard && navigator.clipboard.writeText(v).then(function () { toast('Copied to clipboard'); }); });
  window.addEventListener('beforeunload', function (e) { if (dirty) { e.preventDefault(); e.returnValue = A.i18n.unsaved; } });

  /* ---------- Stats ---------- */
  function stats() {
    var days = $('input[name=swcp-range]:checked').val() || 30;
    post('stats', { days: days }).done(function (r) {
      if (!r.success) return; var d = r.data;
      $('#k-open').text(d.total_open); $('#k-click').text(d.total_click);
      $('#k-rate').text(d.total_open ? Math.round(d.total_click / d.total_open * 100) + '%' : '—');
      var dev = d.mobile + d.desktop; $('#k-mobile').text(dev ? Math.round(d.mobile / dev * 100) + '%' : '—');
      var names = { main: S.agent_name || 'Main number', shortcode: 'Shortcode buttons' };
      (S.agents || []).forEach(function (a) { if (a.id) names[a.id] = a.name; });
      var top = Object.keys(d.agents).sort(function (a, b) { return d.agents[b] - d.agents[a]; }).slice(0, 6);
      $('#swcp-top-agents').html(top.length ? top.map(function (k) { return '<li class="list-group-item d-flex justify-content-between px-0"><span><i class="bi bi-person-circle me-2 text-success"></i>' + esc(names[k] || k) + '</span><span class="badge rounded-pill text-bg-success">' + d.agents[k] + '</span></li>'; }).join('') : '<li class="list-group-item px-0 text-body-secondary small">No chats recorded yet.</li>');
      if (!window.Chart) return;
      var ds = [{ label: 'Opens', data: d.open, borderColor: '#128C7E', backgroundColor: 'rgba(18,140,126,.12)', fill: true, tension: .35 }, { label: 'Chats', data: d.click, borderColor: '#25D366', backgroundColor: 'rgba(37,211,102,.15)', fill: true, tension: .35 }];
      if (chart) { chart.data.labels = d.labels; chart.data.datasets[0].data = d.open; chart.data.datasets[1].data = d.click; chart.update(); return; }
      chart = new Chart(document.getElementById('swcp-chart'), { type: 'line', data: { labels: d.labels, datasets: ds }, options: { responsive: true, maintainAspectRatio: false, interaction: { mode: 'index', intersect: false }, plugins: { legend: { position: 'bottom' } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } }, x: { grid: { display: false } } } } });
    });
  }
  $('input[name=swcp-range]').on('change', stats);

  // Deep-link tabs via hash
  $root.on('shown.bs.tab', '[data-tab]', function () { history.replaceState(null, '', '#' + $(this).data('tab')); });
  var h = location.hash.replace('#', ''); if (h && $('[data-tab="' + h + '"]').length) bootstrap.Tab.getOrCreateInstance($('[data-tab="' + h + '"]')[0]).show();

  fill(); stats();
})(jQuery);
