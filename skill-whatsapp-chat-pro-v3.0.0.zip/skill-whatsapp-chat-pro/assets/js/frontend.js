/* Skill WhatsApp Chat Pro v3 — frontend controller (vanilla, no dependencies). */
(function () {
  'use strict';
  var D = window.SWCP_DATA || {};
  var KEY = 'swcp_closed';
  function ready(fn) { document.readyState !== 'loading' ? fn() : document.addEventListener('DOMContentLoaded', fn); }
  function isMobile() { return window.matchMedia('(max-width: 768px)').matches; }
  function store(k, v) { try { if (v === undefined) return sessionStorage.getItem(k); sessionStorage.setItem(k, v); } catch (e) { return null; } }

  function track(event, agent) {
    if (D.ga4 && typeof window.gtag === 'function') {
      window.gtag('event', event === 'click' ? 'whatsapp_click' : 'whatsapp_open', { agent: agent || 'main' });
    }
    if (window.dataLayer && D.ga4) window.dataLayer.push({ event: 'swcp_' + event, swcp_agent: agent || 'main' });
    if (!D.analytics || !D.ajax) return;
    var body = new URLSearchParams({ action: 'swcp_track', nonce: D.nonce, event: event, agent: agent || 'main', device: isMobile() ? 'mobile' : 'desktop' });
    if (navigator.sendBeacon) navigator.sendBeacon(D.ajax, body);
    else fetch(D.ajax, { method: 'POST', body: body, credentials: 'same-origin', keepalive: true });
  }

  ready(function () {
    var w = document.getElementById('swcp-widget');
    if (!w) return;
    var btn = w.querySelector('.swcp-btn');
    var popup = w.querySelector('.swcp-popup');
    var gdpr = w.querySelector('.swcp-gdpr-check');

    function isOpen() { return popup && !popup.hidden; }
    function open() {
      if (!popup || isOpen()) return;
      popup.hidden = false; w.classList.add('swcp-is-open', 'swcp-seen');
      btn.setAttribute('aria-expanded', 'true'); track('open');
      var f = popup.querySelector('.swcp-close'); if (f) f.focus({ preventScroll: true });
    }
    function close(remember) {
      if (!isOpen()) return;
      popup.hidden = true; w.classList.remove('swcp-is-open'); btn.setAttribute('aria-expanded', 'false');
      if (remember && D.remember) store(KEY, '1');
      btn.focus({ preventScroll: true });
    }

    if (gdpr) {
      w.classList.add('swcp-locked');
      gdpr.addEventListener('change', function () { w.classList.toggle('swcp-locked', !gdpr.checked); });
    }

    btn.addEventListener('click', function (e) {
      if (popup) { e.preventDefault(); isOpen() ? close(true) : open(); return; }
      track('click', btn.getAttribute('data-swcp-agent'));
    });

    w.addEventListener('click', function (e) {
      var a = e.target.closest('.swcp-cta, .swcp-agent');
      if (a) {
        if (gdpr && !gdpr.checked) { e.preventDefault(); gdpr.focus(); return; }
        track('click', a.getAttribute('data-swcp-agent'));
      }
      if (e.target.closest('.swcp-close')) { e.preventDefault(); close(true); }
    });

    document.addEventListener('click', function (e) { if (isOpen() && !w.contains(e.target)) close(true); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(true); });

    // Shortcode buttons tracking
    document.querySelectorAll('.swcp-sc-btn').forEach(function (b) { b.addEventListener('click', function () { track('click', 'shortcode'); }); });

    // Scroll trigger
    if (D.scroll > 0) {
      var onScroll = function () {
        var h = document.documentElement, pct = (h.scrollTop / Math.max(1, h.scrollHeight - h.clientHeight)) * 100;
        if (pct >= D.scroll) { w.classList.remove('swcp-hidden-scroll'); window.removeEventListener('scroll', onScroll); }
      };
      window.addEventListener('scroll', onScroll, { passive: true }); onScroll();
    }

    if (D.tooltipDelay > 0) setTimeout(function () { w.classList.add('swcp-tooltip-show'); setTimeout(function () { w.classList.remove('swcp-tooltip-show'); }, 6000); }, D.tooltipDelay * 1000);

    if (D.autoOpen && popup && store(KEY) !== '1') setTimeout(open, Math.max(0, D.autoOpenDelay) * 1000);
  });
})();
