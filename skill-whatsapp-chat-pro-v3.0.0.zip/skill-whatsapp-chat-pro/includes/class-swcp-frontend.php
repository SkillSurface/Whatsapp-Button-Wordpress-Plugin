<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SWCP_Frontend {

	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ) );
		add_action( 'wp_footer', array( $this, 'render' ), 99 );
		add_shortcode( 'whatsapp_button', array( $this, 'shortcode' ) );
		add_shortcode( 'swcp_button', array( $this, 'shortcode' ) );
	}

	/** Agents that should be displayed (falls back to the main number). */
	public static function agents() {
		$o = SWCP_Settings::get();
		$list = array_values( array_filter( (array) $o['agents'], function ( $a ) { return ! empty( $a['active'] ); } ) );
		if ( ! $list && $o['phone'] ) {
			$list[] = array( 'id' => 'main', 'name' => $o['agent_name'], 'role' => $o['agent_title'], 'phone' => $o['phone'], 'avatar' => $o['agent_avatar'], 'message' => '' );
		}
		return $list;
	}

	public function should_show() {
		$o = SWCP_Settings::get();
		if ( empty( $o['enabled'] ) || ! self::agents() ) return false;
		if ( is_admin() || wp_doing_ajax() || is_feed() ) return false;
		if ( ! empty( $o['hide_logged_in'] ) && is_user_logged_in() ) return false;
		if ( ! empty( $o['hide_woo_checkout'] ) && function_exists( 'is_checkout' ) && is_checkout() ) return false;
		if ( ! empty( $o['hours_enabled'] ) && 'hide' === $o['offline_action'] && ! SWCP_Settings::is_open_now() ) return false;

		$ids = array_filter( array_map( 'absint', explode( ',', (string) $o['page_ids'] ) ) );
		$id  = (int) get_queried_object_id();
		if ( 'include' === $o['display_rule'] && ! in_array( $id, $ids, true ) ) return false;
		if ( 'exclude' === $o['display_rule'] && in_array( $id, $ids, true ) ) return false;
		return (bool) apply_filters( 'swcp_should_show', true, $o );
	}

	/** Replace dynamic placeholders: {page_title} {page_url} {site_name}. */
	public static function placeholders( $msg ) {
		$title = is_singular() ? get_the_title() : wp_get_document_title();
		$url   = home_url( add_query_arg( array(), $GLOBALS['wp']->request ?? '' ) );
		return strtr( (string) $msg, array( '{page_title}' => wp_strip_all_tags( $title ), '{page_url}' => $url, '{site_name}' => get_bloginfo( 'name' ) ) );
	}

	/** Official click-to-chat URL format: https://wa.me/<number>?text=<urlencoded>. */
	public static function wa_link( $phone, $msg = '' ) {
		$digits = SWCP_Settings::phone( $phone );
		if ( '' === $digits ) return '';
		$url = 'https://wa.me/' . $digits;
		$msg = trim( self::placeholders( $msg ) );
		return '' !== $msg ? $url . '?text=' . rawurlencode( $msg ) : $url;
	}

	public function enqueue() {
		if ( ! $this->should_show() ) return;
		$o = SWCP_Settings::get();
		wp_enqueue_style( 'swcp-frontend', SWCP_URL . 'assets/css/frontend.css', array(), SWCP_VERSION );
		if ( $o['custom_css'] ) wp_add_inline_style( 'swcp-frontend', $o['custom_css'] );
		wp_enqueue_script( 'swcp-frontend', SWCP_URL . 'assets/js/frontend.js', array(), SWCP_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
		wp_localize_script( 'swcp-frontend', 'SWCP_DATA', array(
			'ajax'          => admin_url( 'admin-ajax.php' ),
			'nonce'         => wp_create_nonce( 'swcp_track' ),
			'mode'          => $o['mode'],
			'autoOpen'      => (int) $o['auto_open'],
			'autoOpenDelay' => (int) $o['auto_open_delay'],
			'remember'      => (int) $o['remember_close'],
			'tooltipDelay'  => (int) $o['tooltip_delay'],
			'scroll'        => (int) $o['scroll_trigger'],
			'newTab'        => (int) $o['open_new_tab'],
			'gdpr'          => (int) $o['gdpr_enabled'],
			'analytics'     => (int) $o['analytics_enabled'],
			'ga4'           => (int) $o['ga4_event'],
		) );
	}

	public static function icon( $style = 'classic', $size = 28 ) {
		$path = 'M19.11 17.21c-.27-.14-1.6-.79-1.85-.88-.25-.09-.43-.14-.61.14-.18.27-.7.88-.86 1.06-.16.18-.32.2-.59.07-.27-.14-1.14-.42-2.18-1.34-.81-.72-1.35-1.61-1.51-1.88-.16-.27-.02-.41.12-.55.12-.12.27-.32.41-.48.14-.16.18-.27.27-.45.09-.18.05-.34-.02-.48-.07-.14-.61-1.46-.83-2-.22-.53-.45-.46-.61-.47l-.52-.01c-.18 0-.48.07-.73.34-.25.27-.95.93-.95 2.27 0 1.34.97 2.63 1.11 2.81.14.18 1.92 2.93 4.65 4.11.65.28 1.16.45 1.55.58.65.21 1.24.18 1.71.11.52-.08 1.6-.65 1.83-1.28.23-.63.23-1.17.16-1.28-.07-.11-.25-.18-.52-.32zM16.02 5.33c-5.89 0-10.67 4.78-10.67 10.67 0 1.88.49 3.71 1.43 5.33L5.33 26.67l5.51-1.45a10.62 10.62 0 0 0 5.18 1.32h.01c5.89 0 10.67-4.78 10.67-10.67S21.91 5.33 16.02 5.33zm0 19.55h-.01a8.86 8.86 0 0 1-4.51-1.24l-.32-.19-3.27.86.87-3.19-.21-.33a8.85 8.850 0 0 1-1.36-4.74c0-4.9 3.99-8.89 8.89-8.89 2.37 0 4.6.93 6.28 2.6a8.81 8.81 0 0 1 2.6 6.29c0 4.9-3.99 8.83-8.96 8.83z';
		if ( 'outline' === $style ) {
			return '<svg viewBox="0 0 24 24" width="' . (int) $size . '" height="' . (int) $size . '" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 21l1.65-3.8a9 9 0 1 1 3.4 2.9L3 21"/><path d="M9 10a.5.5 0 0 0 1 0V9a.5.5 0 0 0-1 0v1a5 5 0 0 0 5 5h1a.5.5 0 0 0 0-1h-1a.5.5 0 0 0 0 1"/></svg>';
		}
		return '<svg viewBox="0 0 32 32" width="' . (int) $size . '" height="' . (int) $size . '" fill="currentColor" aria-hidden="true"><path d="' . $path . '"/></svg>';
	}

	public function shortcode( $atts ) {
		$o = SWCP_Settings::get();
		$atts = shortcode_atts( array(
			'text'  => $o['button_text'] ?: __( 'Chat on WhatsApp', 'skill-whatsapp-chat-pro' ),
			'phone' => $o['phone'] ?: ( self::agents()[0]['phone'] ?? '' ),
			'msg'   => $o['prefilled'],
			'style' => 'solid', // solid | outline | pill
			'align' => '',      // left | center | right
		), $atts, 'whatsapp_button' );
		$href = self::wa_link( $atts['phone'], $atts['msg'] );
		if ( '' === $href ) return '';
		wp_enqueue_style( 'swcp-frontend', SWCP_URL . 'assets/css/frontend.css', array(), SWCP_VERSION );
		$cls = 'swcp-sc-btn swcp-sc-' . sanitize_html_class( $atts['style'] );
		$wrap = $atts['align'] ? ' style="text-align:' . esc_attr( in_array( $atts['align'], array( 'left','center','right' ), true ) ? $atts['align'] : 'left' ) . '"' : '';
		return '<div class="swcp-sc-wrap"' . $wrap . '><a class="' . esc_attr( $cls ) . '" href="' . esc_url( $href ) . '" target="_blank" rel="noopener noreferrer nofollow" data-swcp-agent="shortcode">'
			. self::icon( 'classic', 22 ) . '<span>' . esc_html( $atts['text'] ) . '</span></a></div>';
	}

	public function render() {
		if ( ! $this->should_show() ) return;
		$o       = SWCP_Settings::get();
		$open    = SWCP_Settings::is_open_now();
		$agents  = self::agents();
		$single  = count( $agents ) === 1;
		$first   = $agents[0];
		$fallback= $open ? $o['prefilled'] : ( $o['hours_offline_msg'] ?: $o['prefilled'] );
		$main    = self::wa_link( $first['phone'], $first['message'] ?: $fallback );
		$target  = $o['open_new_tab'] ? ' target="_blank" rel="noopener noreferrer nofollow"' : ' rel="nofollow"';

		$style = sprintf( '--swcp-bg:%s;--swcp-icon:%s;--swcp-header:%s;--swcp-x:%dpx;--swcp-y:%dpx;--swcp-size:%dpx;--swcp-z:%d;',
			$o['bg_color'], $o['icon_color'], $o['header_color'], $o['offset_x'], $o['offset_y'], $o['button_size'], $o['z_index'] );
		$classes = array( 'swcp-wrap', 'swcp-' . $o['position'], 'swcp-show-' . $o['show_on'], 'swcp-theme-' . $o['theme'], 'swcp-shape-' . $o['button_shape'], 'swcp-anim-' . $o['animation'] );
		if ( $o['scroll_trigger'] ) $classes[] = 'swcp-hidden-scroll';

		$icon = ( 'custom' === $o['icon_style'] && $o['custom_icon'] )
			? '<img src="' . esc_url( $o['custom_icon'] ) . '" alt="" width="32" height="32" loading="lazy" />'
			: self::icon( $o['icon_style'], 30 );
		?>
<div id="swcp-widget" class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>" style="<?php echo esc_attr( $style ); ?>" data-href="<?php echo esc_url( $main ); ?>">
	<?php if ( 'popup' === $o['mode'] ) : ?>
	<div class="swcp-popup" id="swcp-popup" role="dialog" aria-modal="false" aria-labelledby="swcp-title" hidden>
		<div class="swcp-head">
			<div class="swcp-head-icon"><?php echo self::icon( 'classic', 34 ); // phpcs:ignore ?></div>
			<div class="swcp-head-text">
				<strong id="swcp-title"><?php echo esc_html( $single ? $first['name'] : $o['popup_title'] ); ?></strong>
				<small><?php echo esc_html( $single ? ( $open ? $first['role'] : __( 'Currently offline', 'skill-whatsapp-chat-pro' ) ) : $o['popup_subtitle'] ); ?></small>
			</div>
			<button type="button" class="swcp-close" aria-label="<?php esc_attr_e( 'Close chat', 'skill-whatsapp-chat-pro' ); ?>">&times;</button>
		</div>
		<div class="swcp-body">
			<?php if ( $single ) : ?>
				<div class="swcp-bubble"><span class="swcp-bubble-name"><?php echo esc_html( $first['name'] ); ?></span><?php echo nl2br( esc_html( $open ? $o['welcome_msg'] : $o['hours_offline_msg'] ) ); ?><time><?php echo esc_html( SWCP_Settings::now()->format( 'H:i' ) ); ?></time></div>
			<?php else : ?>
				<?php if ( ! $open ) : ?><div class="swcp-offline-note"><?php echo esc_html( $o['hours_offline_msg'] ); ?></div><?php endif; ?>
				<ul class="swcp-agents">
				<?php foreach ( $agents as $a ) : $link = self::wa_link( $a['phone'], $a['message'] ?: $fallback ); ?>
					<li><a class="swcp-agent" href="<?php echo esc_url( $link ); ?>"<?php echo $target; // phpcs:ignore ?> data-swcp-agent="<?php echo esc_attr( $a['id'] ); ?>">
						<span class="swcp-avatar"><?php if ( $a['avatar'] ) : ?><img src="<?php echo esc_url( $a['avatar'] ); ?>" alt="" loading="lazy" width="44" height="44" /><?php else : ?><?php echo esc_html( mb_strtoupper( mb_substr( $a['name'] ?: 'A', 0, 1 ) ) ); ?><?php endif; ?><i class="swcp-dot <?php echo $open ? 'on' : 'off'; ?>"></i></span>
						<span class="swcp-agent-meta"><strong><?php echo esc_html( $a['name'] ); ?></strong><small><?php echo esc_html( $a['role'] ); ?></small></span>
						<span class="swcp-agent-go"><?php echo self::icon( 'classic', 20 ); // phpcs:ignore ?></span>
					</a></li>
				<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>
		<div class="swcp-foot">
			<?php if ( $o['gdpr_enabled'] ) : ?>
				<label class="swcp-gdpr"><input type="checkbox" class="swcp-gdpr-check" /> <span><?php echo esc_html( $o['gdpr_text'] ); ?></span></label>
			<?php endif; ?>
			<?php if ( $single ) : ?>
				<a class="swcp-cta" href="<?php echo esc_url( $main ); ?>"<?php echo $target; // phpcs:ignore ?> data-swcp-agent="<?php echo esc_attr( $first['id'] ); ?>"><?php echo self::icon( 'classic', 20 ); // phpcs:ignore ?><span><?php echo esc_html( $o['cta_text'] ); ?></span></a>
			<?php endif; ?>
			<?php if ( $o['footer_note'] ) : ?><p class="swcp-note"><?php echo esc_html( $o['footer_note'] ); ?></p><?php endif; ?>
		</div>
	</div>
	<?php endif; ?>
	<?php if ( $o['show_button_text'] && $o['button_text'] ) : ?><span class="swcp-tooltip" aria-hidden="true"><?php echo esc_html( $o['button_text'] ); ?></span><?php endif; ?>
	<a class="swcp-btn" href="<?php echo esc_url( $main ); ?>"<?php echo $target; // phpcs:ignore ?> aria-label="<?php echo esc_attr( $o['button_text'] ?: __( 'Chat on WhatsApp', 'skill-whatsapp-chat-pro' ) ); ?>" aria-controls="swcp-popup" aria-expanded="false" data-swcp-agent="<?php echo esc_attr( $first['id'] ); ?>">
		<span class="swcp-btn-icon"><?php echo $icon; // phpcs:ignore ?></span>
		<span class="swcp-btn-close" aria-hidden="true">&times;</span>
		<?php if ( $o['notification_badge'] ) : ?><span class="swcp-badge" aria-hidden="true">1</span><?php endif; ?>
	</a>
</div>
		<?php
	}
}
