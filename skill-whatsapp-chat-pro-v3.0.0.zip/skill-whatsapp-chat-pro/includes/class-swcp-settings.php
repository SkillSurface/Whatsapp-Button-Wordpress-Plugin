<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Settings registry: defaults, migration from v2, strict sanitisation, business-hours logic.
 */
class SWCP_Settings {

	const DAYS = array( 'mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun' );

	public static function default_hours() {
		$h = array();
		foreach ( self::DAYS as $d ) $h[ $d ] = array( 'on' => in_array( $d, array( 'sat', 'sun' ), true ) ? 0 : 1, 'from' => '09:00', 'to' => '18:00' );
		return $h;
	}

	public static function defaults() {
		return array(
			// General
			'enabled'            => 1,
			'mode'               => 'popup',          // popup | direct
			'phone'              => '',
			'prefilled'          => 'Hello! I have a question about {page_title}',
			// Agents (multi-agent support)
			'agents'             => array(),
			// Popup content
			'popup_title'        => 'Start a Conversation',
			'popup_subtitle'     => 'Hi! Click one of our members below to chat on WhatsApp.',
			'agent_name'         => 'Support Team',
			'agent_title'        => 'Typically replies within minutes',
			'agent_avatar'       => '',
			'welcome_msg'        => "Hi there! 👋\nHow can we help you today?",
			'cta_text'           => 'Start Chat',
			'footer_note'        => 'Powered by WhatsApp',
			// Button
			'button_text'        => 'Chat with us',
			'show_button_text'   => 1,
			'button_size'        => 60,
			'button_shape'       => 'circle',        // circle | rounded | square
			'animation'          => 'pulse',         // none | pulse | bounce | shake
			'notification_badge' => 1,
			'tooltip_delay'      => 3,
			// Appearance
			'theme'              => 'light',         // light | dark | auto
			'position'           => 'right',
			'offset_x'           => 24,
			'offset_y'           => 24,
			'z_index'            => 99999,
			'bg_color'           => '#25D366',
			'icon_color'         => '#ffffff',
			'header_color'       => '#075E54',
			'icon_style'         => 'classic',       // classic | outline | custom
			'custom_icon'        => '',
			// Behaviour
			'auto_open'          => 0,
			'auto_open_delay'    => 8,
			'remember_close'     => 1,
			'open_new_tab'       => 1,
			'scroll_trigger'     => 0,               // % of page scrolled before button appears
			// Targeting
			'show_on'            => 'all',           // all | desktop | mobile
			'display_rule'       => 'all',           // all | include | exclude
			'page_ids'           => '',
			'hide_logged_in'     => 0,
			'hide_woo_checkout'  => 1,
			// Hours
			'hours_enabled'      => 0,
			'timezone'           => '',
			'hours_offline_msg'  => 'We are currently offline. Leave a message and we will reply as soon as we are back.',
			'offline_action'     => 'message',       // message | hide
			'hours'              => self::default_hours(),
			// Privacy / Analytics
			'gdpr_enabled'       => 0,
			'gdpr_text'          => 'I agree to the privacy policy.',
			'analytics_enabled'  => 1,
			'ga4_event'          => 1,
			// Advanced
			'custom_css'         => '',
			'delete_on_uninstall'=> 0,
		);
	}

	/** Upgrade older option structures (v2.x) without losing data. */
	public static function migrate( $old ) {
		$new = wp_parse_args( $old, self::defaults() );
		if ( isset( $old['hide_pages'] ) && empty( $old['page_ids'] ) && '' !== trim( (string) $old['hide_pages'] ) ) {
			$new['display_rule'] = 'exclude';
			$new['page_ids']     = $old['hide_pages'];
		}
		if ( isset( $new['icon_style'] ) && 'business' === $new['icon_style'] ) $new['icon_style'] = 'outline';
		unset( $new['hide_pages'] );
		return self::sanitize( $new );
	}

	public static function get( $key = null ) {
		$opts = wp_parse_args( (array) get_option( SWCP_OPTION, array() ), self::defaults() );
		if ( null === $key ) return $opts;
		return $opts[ $key ] ?? null;
	}

	public static function phone( $raw ) {
		$d = ltrim( preg_replace( '/\D+/', '', (string) $raw ), '0' );
		return ( strlen( $d ) >= 7 && strlen( $d ) <= 15 ) ? $d : '';
	}

	private static function pick( $val, $allowed, $fallback ) {
		return in_array( $val, $allowed, true ) ? $val : $fallback;
	}

	private static function int( $v, $min, $max, $def ) {
		return is_numeric( $v ) ? max( $min, min( $max, (int) $v ) ) : $def;
	}

	public static function sanitize( $in ) {
		$d   = self::defaults();
		$in  = is_array( $in ) ? $in : array();
		$o   = array();
		$bool = array( 'enabled','show_button_text','notification_badge','auto_open','remember_close','open_new_tab','hide_logged_in','hide_woo_checkout','hours_enabled','gdpr_enabled','analytics_enabled','ga4_event','delete_on_uninstall' );
		foreach ( $bool as $k ) $o[ $k ] = ! empty( $in[ $k ] ) ? 1 : 0;

		$text = array( 'popup_title','popup_subtitle','agent_name','agent_title','cta_text','footer_note','button_text','gdpr_text' );
		foreach ( $text as $k ) $o[ $k ] = sanitize_text_field( $in[ $k ] ?? $d[ $k ] );
		foreach ( array( 'prefilled','welcome_msg','hours_offline_msg' ) as $k ) $o[ $k ] = sanitize_textarea_field( $in[ $k ] ?? $d[ $k ] );

		$o['phone']         = self::phone( $in['phone'] ?? '' );
		$o['agent_avatar']  = esc_url_raw( $in['agent_avatar'] ?? '' );
		$o['custom_icon']   = esc_url_raw( $in['custom_icon'] ?? '' );
		$o['mode']          = self::pick( $in['mode'] ?? '', array( 'popup','direct' ), 'popup' );
		$o['button_shape']  = self::pick( $in['button_shape'] ?? '', array( 'circle','rounded','square' ), 'circle' );
		$o['animation']     = self::pick( $in['animation'] ?? '', array( 'none','pulse','bounce','shake' ), 'pulse' );
		$o['theme']         = self::pick( $in['theme'] ?? '', array( 'light','dark','auto' ), 'light' );
		$o['position']      = self::pick( $in['position'] ?? '', array( 'right','left' ), 'right' );
		$o['icon_style']    = self::pick( $in['icon_style'] ?? '', array( 'classic','outline','custom' ), 'classic' );
		$o['show_on']       = self::pick( $in['show_on'] ?? '', array( 'all','desktop','mobile' ), 'all' );
		$o['display_rule']  = self::pick( $in['display_rule'] ?? '', array( 'all','include','exclude' ), 'all' );
		$o['offline_action']= self::pick( $in['offline_action'] ?? '', array( 'message','hide' ), 'message' );
		$o['button_size']   = self::int( $in['button_size'] ?? null, 40, 90, 60 );
		$o['tooltip_delay'] = self::int( $in['tooltip_delay'] ?? null, 0, 60, 3 );
		$o['offset_x']      = self::int( $in['offset_x'] ?? null, 0, 300, 24 );
		$o['offset_y']      = self::int( $in['offset_y'] ?? null, 0, 300, 24 );
		$o['z_index']       = self::int( $in['z_index'] ?? null, 1, 2147483647, 99999 );
		$o['auto_open_delay'] = self::int( $in['auto_open_delay'] ?? null, 0, 300, 8 );
		$o['scroll_trigger']  = self::int( $in['scroll_trigger'] ?? null, 0, 100, 0 );
		foreach ( array( 'bg_color' => '#25D366', 'icon_color' => '#ffffff', 'header_color' => '#075E54' ) as $k => $def ) {
			$o[ $k ] = sanitize_hex_color( $in[ $k ] ?? '' ) ?: $def;
		}
		$o['page_ids'] = implode( ',', array_filter( array_map( 'absint', explode( ',', (string) ( $in['page_ids'] ?? '' ) ) ) ) );
		$tz = sanitize_text_field( $in['timezone'] ?? '' );
		$o['timezone'] = ( '' === $tz || in_array( $tz, timezone_identifiers_list(), true ) ) ? $tz : '';
		$o['custom_css'] = wp_strip_all_tags( $in['custom_css'] ?? '' );

		$hours = array();
		foreach ( self::DAYS as $day ) {
			$h = (array) ( $in['hours'][ $day ] ?? array() );
			$hours[ $day ] = array(
				'on'   => ! empty( $h['on'] ) ? 1 : 0,
				'from' => preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $h['from'] ?? '' ) ? $h['from'] : '09:00',
				'to'   => preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $h['to'] ?? '' ) ? $h['to'] : '18:00',
			);
		}
		$o['hours'] = $hours;

		$agents = array();
		foreach ( array_slice( (array) ( $in['agents'] ?? array() ), 0, 20 ) as $a ) {
			$a     = (array) $a;
			$phone = self::phone( $a['phone'] ?? '' );
			if ( '' === $phone ) continue;
			$agents[] = array(
				'id'      => sanitize_key( $a['id'] ?? '' ) ?: substr( md5( $phone . wp_rand() ), 0, 8 ),
				'name'    => sanitize_text_field( $a['name'] ?? '' ),
				'role'    => sanitize_text_field( $a['role'] ?? '' ),
				'phone'   => $phone,
				'avatar'  => esc_url_raw( $a['avatar'] ?? '' ),
				'message' => sanitize_textarea_field( $a['message'] ?? '' ),
				'active'  => ! empty( $a['active'] ) ? 1 : 0,
			);
		}
		$o['agents'] = $agents;
		return $o;
	}

	public static function now() {
		$tz = self::get( 'timezone' );
		try { $zone = $tz ? new DateTimeZone( $tz ) : wp_timezone(); } catch ( Exception $e ) { $zone = wp_timezone(); }
		return new DateTime( 'now', $zone );
	}

	/** Supports overnight ranges (e.g. 22:00 – 02:00). */
	public static function is_open_now() {
		$o = self::get();
		if ( empty( $o['hours_enabled'] ) ) return true;
		$now = self::now();
		$day = strtolower( $now->format( 'D' ) );
		$h   = $o['hours'][ $day ] ?? null;
		if ( ! $h || empty( $h['on'] ) ) return false;
		$t = $now->format( 'H:i' );
		if ( $h['from'] <= $h['to'] ) return $t >= $h['from'] && $t <= $h['to'];
		return $t >= $h['from'] || $t <= $h['to'];
	}
}
