<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Admin dashboard: Bootstrap 5.3 UI, AJAX save / reset / import / page search / stats.
 * All AJAX endpoints require `manage_options` + a nonce.
 */
class SWCP_Admin {

	const CAP = 'manage_options';
	private $hook = '';

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		foreach ( array( 'save', 'reset', 'import', 'search_pages', 'stats', 'clear_stats' ) as $a ) {
			add_action( 'wp_ajax_swcp_' . $a, array( $this, 'ajax_' . $a ) );
		}
	}

	public function menu() {
		$icon = 'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" fill="#a7aaad"><path d="M16 3C8.8 3 3 8.8 3 16c0 2.3.6 4.5 1.7 6.5L3 29l6.7-1.7c1.9 1 4.1 1.6 6.3 1.6 7.2 0 13-5.8 13-13S23.2 3 16 3zm6.3 18.5c-.3.8-1.6 1.5-2.2 1.6-.6.1-1.3.1-2.1-.1-.5-.2-1.1-.4-1.9-.7-3.3-1.4-5.5-4.8-5.6-5-.2-.2-1.4-1.8-1.4-3.4 0-1.6.9-2.4 1.2-2.8.3-.3.6-.4.9-.4h.6c.2 0 .5-.1.7.6.3.7.9 2.3 1 2.4.1.2.1.4 0 .6-.1.2-.2.4-.3.5l-.5.6c-.2.2-.3.3-.1.7.2.3.9 1.5 1.9 2.4 1.3 1.1 2.4 1.5 2.7 1.7.3.2.5.1.7-.1.2-.2.8-.9 1-1.3.2-.3.4-.3.7-.2.3.1 1.9.9 2.2 1.1.3.2.5.2.6.4.1.1.1.8-.2 1.6z"/></svg>' );
		$this->hook = add_menu_page( __( 'WhatsApp Chat Pro', 'skill-whatsapp-chat-pro' ), __( 'WhatsApp Chat', 'skill-whatsapp-chat-pro' ), self::CAP, 'swcp', array( $this, 'page' ), $icon, 58 );
	}

	public function assets( $hook ) {
		if ( $hook !== $this->hook ) return;
		$v = SWCP_URL . 'assets/vendor/';
		wp_enqueue_media();
		wp_enqueue_style( 'swcp-bootstrap', $v . 'bootstrap.min.css', array(), '5.3.3' );
		wp_enqueue_style( 'swcp-bi', $v . 'bootstrap-icons.min.css', array(), '1.11.3' );
		wp_enqueue_style( 'swcp-front', SWCP_URL . 'assets/css/frontend.css', array(), SWCP_VERSION );
		wp_enqueue_style( 'swcp-admin', SWCP_URL . 'assets/css/admin.css', array( 'swcp-bootstrap' ), SWCP_VERSION );
		wp_enqueue_script( 'swcp-bootstrap', $v . 'bootstrap.bundle.min.js', array(), '5.3.3', true );
		wp_enqueue_script( 'swcp-chart', $v . 'chart.umd.min.js', array(), '4.4.4', true );
		wp_enqueue_script( 'swcp-admin', SWCP_URL . 'assets/js/admin.js', array( 'jquery', 'swcp-bootstrap', 'swcp-chart' ), SWCP_VERSION, true );
		wp_localize_script( 'swcp-admin', 'SWCP_ADMIN', array(
			'ajax'     => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'swcp_admin' ),
			'settings' => SWCP_Settings::get(),
			'icon'     => SWCP_Frontend::icon( 'classic', 30 ),
			'iconOut'  => SWCP_Frontend::icon( 'outline', 30 ),
			'i18n'     => array(
				'saved' => __( 'Settings saved successfully.', 'skill-whatsapp-chat-pro' ),
				'error' => __( 'Something went wrong. Please try again.', 'skill-whatsapp-chat-pro' ),
				'reset' => __( 'Reset ALL settings to defaults? This cannot be undone.', 'skill-whatsapp-chat-pro' ),
				'clear' => __( 'Delete all analytics data?', 'skill-whatsapp-chat-pro' ),
				'unsaved' => __( 'You have unsaved changes.', 'skill-whatsapp-chat-pro' ),
			),
		) );
	}

	private function guard() {
		if ( ! current_user_can( self::CAP ) ) wp_send_json_error( array( 'message' => __( 'Permission denied.', 'skill-whatsapp-chat-pro' ) ), 403 );
		check_ajax_referer( 'swcp_admin', 'nonce' );
	}

	private function payload() {
		$raw = wp_unslash( $_POST['settings'] ?? '' ); // phpcs:ignore
		$data = json_decode( (string) $raw, true );
		return is_array( $data ) ? $data : null;
	}

	public function ajax_save() {
		$this->guard();
		$data = $this->payload();
		if ( null === $data ) wp_send_json_error( array( 'message' => 'Invalid payload' ), 400 );
		$clean = SWCP_Settings::sanitize( $data );
		update_option( SWCP_OPTION, $clean );
		do_action( 'swcp_settings_saved', $clean );
		wp_send_json_success( array( 'settings' => $clean ) );
	}

	public function ajax_reset() {
		$this->guard();
		update_option( SWCP_OPTION, SWCP_Settings::defaults() );
		wp_send_json_success( array( 'settings' => SWCP_Settings::defaults() ) );
	}

	public function ajax_import() {
		$this->guard();
		$data = $this->payload();
		if ( null === $data ) wp_send_json_error( array( 'message' => __( 'Invalid JSON file.', 'skill-whatsapp-chat-pro' ) ), 400 );
		$clean = SWCP_Settings::migrate( $data );
		update_option( SWCP_OPTION, $clean );
		wp_send_json_success( array( 'settings' => $clean ) );
	}

	public function ajax_search_pages() {
		$this->guard();
		$q   = sanitize_text_field( wp_unslash( $_POST['q'] ?? '' ) );
		$ids = array_filter( array_map( 'absint', explode( ',', sanitize_text_field( wp_unslash( $_POST['ids'] ?? '' ) ) ) ) );
		$args = array( 'post_type' => array_values( get_post_types( array( 'public' => true ) ) ), 'post_status' => 'publish', 'posts_per_page' => 15, 'no_found_rows' => true );
		if ( $ids ) { $args['post__in'] = $ids; $args['orderby'] = 'post__in'; $args['posts_per_page'] = 100; } else { $args['s'] = $q; }
		$out = array();
		foreach ( get_posts( $args ) as $p ) {
			$out[] = array( 'id' => $p->ID, 'title' => get_the_title( $p ) ?: '#' . $p->ID, 'type' => get_post_type_object( $p->post_type )->labels->singular_name );
		}
		wp_send_json_success( $out );
	}

	public function ajax_stats() {
		$this->guard();
		$days = in_array( (int) ( $_POST['days'] ?? 30 ), array( 7, 30, 90 ), true ) ? (int) $_POST['days'] : 30;
		wp_send_json_success( SWCP_Analytics::summary( $days ) );
	}

	public function ajax_clear_stats() {
		$this->guard();
		update_option( SWCP_STATS, array(), false );
		wp_send_json_success();
	}

	/* ---------- View helpers ---------- */
	private function sw( $key, $label, $help = '' ) {
		printf( '<div class="form-check form-switch swcp-switch mb-3"><input class="form-check-input" type="checkbox" role="switch" id="f-%1$s" data-key="%1$s"><label class="form-check-label fw-medium" for="f-%1$s">%2$s</label>%3$s</div>',
			esc_attr( $key ), esc_html( $label ), $help ? '<div class="form-text">' . esc_html( $help ) . '</div>' : '' );
	}
	private function input( $key, $label, $type = 'text', $help = '', $attrs = '' ) {
		printf( '<div class="mb-3"><label class="form-label fw-medium" for="f-%1$s">%2$s</label><input type="%3$s" class="form-control" id="f-%1$s" data-key="%1$s" %5$s>%4$s</div>',
			esc_attr( $key ), esc_html( $label ), esc_attr( $type ), $help ? '<div class="form-text">' . wp_kses_post( $help ) . '</div>' : '', $attrs ); // phpcs:ignore
	}
	private function textarea( $key, $label, $help = '', $rows = 3 ) {
		printf( '<div class="mb-3"><label class="form-label fw-medium" for="f-%1$s">%2$s</label><textarea class="form-control" rows="%4$d" id="f-%1$s" data-key="%1$s"></textarea>%3$s</div>',
			esc_attr( $key ), esc_html( $label ), $help ? '<div class="form-text">' . wp_kses_post( $help ) . '</div>' : '', (int) $rows );
	}
	private function select( $key, $label, $opts, $help = '' ) {
		echo '<div class="mb-3"><label class="form-label fw-medium" for="f-' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label><select class="form-select" id="f-' . esc_attr( $key ) . '" data-key="' . esc_attr( $key ) . '">';
		foreach ( $opts as $v => $l ) echo '<option value="' . esc_attr( $v ) . '">' . esc_html( $l ) . '</option>';
		echo '</select>' . ( $help ? '<div class="form-text">' . esc_html( $help ) . '</div>' : '' ) . '</div>';
	}
	private function color( $key, $label ) {
		printf( '<div class="col-sm-4 mb-3"><label class="form-label fw-medium" for="f-%1$s">%2$s</label><div class="input-group"><input type="color" class="form-control form-control-color" id="f-%1$s" data-key="%1$s"><input type="text" class="form-control font-monospace swcp-hex" data-mirror="%1$s" maxlength="7"></div></div>', esc_attr( $key ), esc_html( $label ) );
	}
	private function card_open( $icon, $title, $sub = '' ) {
		echo '<div class="card swcp-card mb-4"><div class="card-header"><i class="bi bi-' . esc_attr( $icon ) . '"></i><div><h2 class="h6 mb-0">' . esc_html( $title ) . '</h2>' . ( $sub ? '<small class="text-body-secondary">' . esc_html( $sub ) . '</small>' : '' ) . '</div></div><div class="card-body">';
	}
	private function card_close() { echo '</div></div>'; }

	public function page() {
		if ( ! current_user_can( self::CAP ) ) return;
		$tabs = array(
			'dashboard' => array( 'speedometer2', __( 'Dashboard', 'skill-whatsapp-chat-pro' ) ),
			'general'   => array( 'whatsapp', __( 'General', 'skill-whatsapp-chat-pro' ) ),
			'agents'    => array( 'people', __( 'Agents', 'skill-whatsapp-chat-pro' ) ),
			'design'    => array( 'palette', __( 'Design', 'skill-whatsapp-chat-pro' ) ),
			'behaviour' => array( 'lightning-charge', __( 'Behaviour', 'skill-whatsapp-chat-pro' ) ),
			'display'   => array( 'funnel', __( 'Display Rules', 'skill-whatsapp-chat-pro' ) ),
			'hours'     => array( 'clock-history', __( 'Business Hours', 'skill-whatsapp-chat-pro' ) ),
			'privacy'   => array( 'shield-check', __( 'Privacy & Tracking', 'skill-whatsapp-chat-pro' ) ),
			'advanced'  => array( 'gear', __( 'Advanced & Tools', 'skill-whatsapp-chat-pro' ) ),
		);
		$days = array( 'mon' => 'Monday', 'tue' => 'Tuesday', 'wed' => 'Wednesday', 'thu' => 'Thursday', 'fri' => 'Friday', 'sat' => 'Saturday', 'sun' => 'Sunday' );
		?>
<div class="wrap swcp-admin" data-bs-theme="light">
	<h1 class="screen-reader-text"><?php esc_html_e( 'WhatsApp Chat Pro', 'skill-whatsapp-chat-pro' ); ?></h1>
	<header class="swcp-topbar">
		<div class="d-flex align-items-center gap-3">
			<span class="swcp-logo"><i class="bi bi-whatsapp"></i></span>
			<div><div class="fw-bold fs-5 lh-sm">WhatsApp Chat Pro</div><small class="opacity-75">v<?php echo esc_html( SWCP_VERSION ); ?> · <?php esc_html_e( 'Floating Chat & Support Agents', 'skill-whatsapp-chat-pro' ); ?></small></div>
		</div>
		<div class="d-flex align-items-center gap-2">
			<span class="swcp-dirty badge text-bg-warning d-none"><i class="bi bi-dot"></i><?php esc_html_e( 'Unsaved', 'skill-whatsapp-chat-pro' ); ?></span>
			<div class="form-check form-switch m-0 swcp-master"><input class="form-check-input" type="checkbox" role="switch" id="f-enabled-top" data-key="enabled"><label class="form-check-label" for="f-enabled-top"><?php esc_html_e( 'Widget live', 'skill-whatsapp-chat-pro' ); ?></label></div>
			<button type="button" class="btn btn-light fw-semibold swcp-save"><span class="spinner-border spinner-border-sm d-none me-1"></span><i class="bi bi-check2-circle me-1"></i><?php esc_html_e( 'Save changes', 'skill-whatsapp-chat-pro' ); ?></button>
		</div>
	</header>

	<div class="swcp-layout">
		<nav class="swcp-nav nav flex-column nav-pills" role="tablist">
			<?php $i = 0; foreach ( $tabs as $id => $t ) : ?>
				<button class="nav-link <?php echo 0 === $i++ ? 'active' : ''; ?>" data-bs-toggle="pill" data-bs-target="#tab-<?php echo esc_attr( $id ); ?>" type="button" role="tab" data-tab="<?php echo esc_attr( $id ); ?>"><i class="bi bi-<?php echo esc_attr( $t[0] ); ?>"></i><span><?php echo esc_html( $t[1] ); ?></span></button>
			<?php endforeach; ?>
			<a class="nav-link mt-2" href="#" data-bs-toggle="modal" data-bs-target="#swcp-help"><i class="bi bi-question-circle"></i><span><?php esc_html_e( 'Quick help', 'skill-whatsapp-chat-pro' ); ?></span></a>
		</nav>

		<main class="tab-content swcp-main">
			<!-- DASHBOARD -->
			<section class="tab-pane fade show active" id="tab-dashboard" role="tabpanel">
				<div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
					<div><h2 class="h4 mb-0"><?php esc_html_e( 'Overview', 'skill-whatsapp-chat-pro' ); ?></h2><small class="text-body-secondary"><?php esc_html_e( 'Privacy-friendly widget analytics (no personal data stored).', 'skill-whatsapp-chat-pro' ); ?></small></div>
					<div class="btn-group btn-group-sm" role="group">
						<?php foreach ( array( 7, 30, 90 ) as $d ) : ?><input type="radio" class="btn-check" name="swcp-range" id="r<?php echo (int) $d; ?>" value="<?php echo (int) $d; ?>" <?php checked( 30, $d ); ?>><label class="btn btn-outline-success" for="r<?php echo (int) $d; ?>"><?php echo (int) $d; ?>d</label><?php endforeach; ?>
					</div>
				</div>
				<div class="row g-3 mb-4">
					<div class="col-sm-6 col-xl-3"><div class="swcp-kpi"><i class="bi bi-chat-dots"></i><div><span id="k-open">0</span><small><?php esc_html_e( 'Popup opens', 'skill-whatsapp-chat-pro' ); ?></small></div></div></div>
					<div class="col-sm-6 col-xl-3"><div class="swcp-kpi k2"><i class="bi bi-cursor"></i><div><span id="k-click">0</span><small><?php esc_html_e( 'Chats started', 'skill-whatsapp-chat-pro' ); ?></small></div></div></div>
					<div class="col-sm-6 col-xl-3"><div class="swcp-kpi k3"><i class="bi bi-percent"></i><div><span id="k-rate">0%</span><small><?php esc_html_e( 'Conversion', 'skill-whatsapp-chat-pro' ); ?></small></div></div></div>
					<div class="col-sm-6 col-xl-3"><div class="swcp-kpi k4"><i class="bi bi-phone"></i><div><span id="k-mobile">0%</span><small><?php esc_html_e( 'From mobile', 'skill-whatsapp-chat-pro' ); ?></small></div></div></div>
				</div>
				<div class="row g-3">
					<div class="col-xl-8"><div class="card swcp-card h-100"><div class="card-body"><h3 class="h6"><?php esc_html_e( 'Engagement trend', 'skill-whatsapp-chat-pro' ); ?></h3><div style="height:280px"><canvas id="swcp-chart"></canvas></div></div></div></div>
					<div class="col-xl-4"><div class="card swcp-card h-100"><div class="card-body"><h3 class="h6"><?php esc_html_e( 'Top agents', 'skill-whatsapp-chat-pro' ); ?></h3><ul class="list-group list-group-flush" id="swcp-top-agents"></ul></div></div></div>
				</div>
				<div class="card swcp-card mt-4"><div class="card-body"><h3 class="h6 mb-3"><i class="bi bi-list-check me-1"></i><?php esc_html_e( 'Setup checklist', 'skill-whatsapp-chat-pro' ); ?></h3><ul class="list-unstyled mb-0 swcp-checklist" id="swcp-checklist"></ul></div></div>
			</section>

			<!-- GENERAL -->
			<section class="tab-pane fade" id="tab-general" role="tabpanel">
				<?php $this->card_open( 'whatsapp', __( 'WhatsApp connection', 'skill-whatsapp-chat-pro' ), __( 'Main number & default message', 'skill-whatsapp-chat-pro' ) ); ?>
				<?php $this->sw( 'enabled', __( 'Enable floating widget', 'skill-whatsapp-chat-pro' ), __( 'Master switch — turn off to hide the button sitewide without losing settings.', 'skill-whatsapp-chat-pro' ) ); ?>
				<div class="mb-3"><label class="form-label fw-medium" for="f-phone"><?php esc_html_e( 'WhatsApp number', 'skill-whatsapp-chat-pro' ); ?></label>
					<div class="input-group has-validation"><span class="input-group-text"><i class="bi bi-telephone"></i>&nbsp;+</span><input type="tel" class="form-control" id="f-phone" data-key="phone" placeholder="923001234567" inputmode="numeric"><button class="btn btn-outline-success swcp-test" type="button"><i class="bi bi-box-arrow-up-right"></i> <?php esc_html_e( 'Test', 'skill-whatsapp-chat-pro' ); ?></button><div class="invalid-feedback"><?php esc_html_e( 'Enter 7–15 digits in international format (country code + number, no leading 0).', 'skill-whatsapp-chat-pro' ); ?></div></div>
					<div class="form-text"><?php esc_html_e( 'International format with country code, digits only. Used when no agents are added.', 'skill-whatsapp-chat-pro' ); ?></div></div>
				<?php $this->select( 'mode', __( 'Click behaviour', 'skill-whatsapp-chat-pro' ), array( 'popup' => __( 'Show chat popup first (recommended)', 'skill-whatsapp-chat-pro' ), 'direct' => __( 'Open WhatsApp directly', 'skill-whatsapp-chat-pro' ) ) ); ?>
				<?php $this->textarea( 'prefilled', __( 'Pre-filled message', 'skill-whatsapp-chat-pro' ), __( 'Placeholders: <code>{page_title}</code> <code>{page_url}</code> <code>{site_name}</code>', 'skill-whatsapp-chat-pro' ), 2 ); ?>
				<?php $this->card_close(); ?>
				<?php $this->card_open( 'chat-square-text', __( 'Popup content', 'skill-whatsapp-chat-pro' ) ); ?>
				<div class="row"><div class="col-md-6"><?php $this->input( 'popup_title', __( 'Popup title (multi-agent)', 'skill-whatsapp-chat-pro' ) ); ?></div><div class="col-md-6"><?php $this->input( 'popup_subtitle', __( 'Popup subtitle (multi-agent)', 'skill-whatsapp-chat-pro' ) ); ?></div>
				<div class="col-md-6"><?php $this->input( 'agent_name', __( 'Default agent name', 'skill-whatsapp-chat-pro' ) ); ?></div><div class="col-md-6"><?php $this->input( 'agent_title', __( 'Default agent status line', 'skill-whatsapp-chat-pro' ) ); ?></div></div>
				<div class="mb-3"><label class="form-label fw-medium" for="f-agent_avatar"><?php esc_html_e( 'Default avatar', 'skill-whatsapp-chat-pro' ); ?></label><div class="input-group"><input type="url" class="form-control" id="f-agent_avatar" data-key="agent_avatar" placeholder="https://"><button class="btn btn-outline-secondary swcp-media" type="button" data-target="f-agent_avatar"><i class="bi bi-image"></i> <?php esc_html_e( 'Media', 'skill-whatsapp-chat-pro' ); ?></button></div></div>
				<?php $this->textarea( 'welcome_msg', __( 'Welcome message bubble', 'skill-whatsapp-chat-pro' ) ); ?>
				<div class="row"><div class="col-md-6"><?php $this->input( 'cta_text', __( 'Start-chat button label', 'skill-whatsapp-chat-pro' ) ); ?></div><div class="col-md-6"><?php $this->input( 'footer_note', __( 'Footer note', 'skill-whatsapp-chat-pro' ) ); ?></div></div>
				<?php $this->card_close(); ?>
			</section>

			<!-- AGENTS -->
			<section class="tab-pane fade" id="tab-agents" role="tabpanel">
				<div class="card swcp-card mb-4"><div class="card-header justify-content-between"><div class="d-flex gap-2 align-items-center"><i class="bi bi-people"></i><div><h2 class="h6 mb-0"><?php esc_html_e( 'Support agents', 'skill-whatsapp-chat-pro' ); ?></h2><small class="text-body-secondary"><?php esc_html_e( 'Up to 20 agents / departments. Drag to reorder.', 'skill-whatsapp-chat-pro' ); ?></small></div></div><button type="button" class="btn btn-success btn-sm swcp-add-agent"><i class="bi bi-plus-lg"></i> <?php esc_html_e( 'Add agent', 'skill-whatsapp-chat-pro' ); ?></button></div>
				<div class="card-body"><div id="swcp-agents" class="vstack gap-3"></div><div class="swcp-empty text-center py-5 text-body-secondary d-none" id="swcp-agents-empty"><i class="bi bi-person-plus display-6"></i><p class="mt-2 mb-0"><?php esc_html_e( 'No agents yet — the main number from General is used.', 'skill-whatsapp-chat-pro' ); ?></p></div></div></div>
			</section>

			<!-- DESIGN -->
			<section class="tab-pane fade" id="tab-design" role="tabpanel">
				<?php $this->card_open( 'palette', __( 'Colors & theme', 'skill-whatsapp-chat-pro' ) ); ?>
				<div class="row"><?php $this->color( 'bg_color', __( 'Button / accent', 'skill-whatsapp-chat-pro' ) ); $this->color( 'icon_color', __( 'Icon', 'skill-whatsapp-chat-pro' ) ); $this->color( 'header_color', __( 'Popup header', 'skill-whatsapp-chat-pro' ) ); ?></div>
				<div class="d-flex flex-wrap gap-2 mb-3" id="swcp-presets"><span class="small text-body-secondary me-1 align-self-center"><?php esc_html_e( 'Presets:', 'skill-whatsapp-chat-pro' ); ?></span></div>
				<?php $this->select( 'theme', __( 'Popup theme', 'skill-whatsapp-chat-pro' ), array( 'light' => 'Light', 'dark' => 'Dark', 'auto' => __( 'Auto (follow visitor device)', 'skill-whatsapp-chat-pro' ) ) ); ?>
				<?php $this->card_close(); ?>
				<?php $this->card_open( 'circle', __( 'Floating button', 'skill-whatsapp-chat-pro' ) ); ?>
				<div class="row">
					<div class="col-md-6"><?php $this->select( 'icon_style', __( 'Icon style', 'skill-whatsapp-chat-pro' ), array( 'classic' => 'Classic (filled)', 'outline' => 'Outline', 'custom' => __( 'Custom image', 'skill-whatsapp-chat-pro' ) ) ); ?></div>
					<div class="col-md-6"><?php $this->select( 'button_shape', __( 'Shape', 'skill-whatsapp-chat-pro' ), array( 'circle' => 'Circle', 'rounded' => 'Rounded', 'square' => 'Square' ) ); ?></div>
				</div>
				<div class="mb-3 swcp-dep" data-dep="icon_style=custom"><label class="form-label fw-medium" for="f-custom_icon"><?php esc_html_e( 'Custom icon URL', 'skill-whatsapp-chat-pro' ); ?></label><div class="input-group"><input type="url" class="form-control" id="f-custom_icon" data-key="custom_icon"><button class="btn btn-outline-secondary swcp-media" type="button" data-target="f-custom_icon"><i class="bi bi-image"></i></button></div></div>
				<div class="row">
					<div class="col-md-6 mb-3"><label class="form-label fw-medium" for="f-button_size"><?php esc_html_e( 'Size', 'skill-whatsapp-chat-pro' ); ?> <span class="badge text-bg-light" data-out="button_size"></span></label><input type="range" class="form-range" min="40" max="90" id="f-button_size" data-key="button_size"></div>
					<div class="col-md-6"><?php $this->select( 'animation', __( 'Attention animation', 'skill-whatsapp-chat-pro' ), array( 'none' => 'None', 'pulse' => 'Pulse', 'bounce' => 'Bounce', 'shake' => 'Shake' ) ); ?></div>
				</div>
				<?php $this->sw( 'show_button_text', __( 'Show tooltip label next to button', 'skill-whatsapp-chat-pro' ) ); ?>
				<div class="swcp-dep" data-dep="show_button_text=1"><?php $this->input( 'button_text', __( 'Tooltip label', 'skill-whatsapp-chat-pro' ) ); ?></div>
				<?php $this->sw( 'notification_badge', __( 'Show red notification badge', 'skill-whatsapp-chat-pro' ), __( 'Disappears after the visitor opens the popup.', 'skill-whatsapp-chat-pro' ) ); ?>
				<?php $this->card_close(); ?>
				<?php $this->card_open( 'arrows-move', __( 'Position', 'skill-whatsapp-chat-pro' ) ); ?>
				<div class="btn-group mb-3" role="group"><input type="radio" class="btn-check" name="pos" id="pos-left" value="left" data-key="position"><label class="btn btn-outline-success" for="pos-left"><i class="bi bi-box-arrow-in-down-left"></i> Left</label><input type="radio" class="btn-check" name="pos" id="pos-right" value="right" data-key="position"><label class="btn btn-outline-success" for="pos-right">Right <i class="bi bi-box-arrow-in-down-right"></i></label></div>
				<div class="row">
					<div class="col-md-4"><?php $this->input( 'offset_x', __( 'Side offset (px)', 'skill-whatsapp-chat-pro' ), 'number', '', 'min="0" max="300"' ); ?></div>
					<div class="col-md-4"><?php $this->input( 'offset_y', __( 'Bottom offset (px)', 'skill-whatsapp-chat-pro' ), 'number', '', 'min="0" max="300"' ); ?></div>
					<div class="col-md-4"><?php $this->input( 'z_index', __( 'Z-index', 'skill-whatsapp-chat-pro' ), 'number' ); ?></div>
				</div>
				<?php $this->card_close(); ?>
			</section>

			<!-- BEHAVIOUR -->
			<section class="tab-pane fade" id="tab-behaviour" role="tabpanel">
				<?php $this->card_open( 'lightning-charge', __( 'Triggers', 'skill-whatsapp-chat-pro' ) ); ?>
				<?php $this->sw( 'auto_open', __( 'Auto-open popup', 'skill-whatsapp-chat-pro' ) ); ?>
				<div class="swcp-dep" data-dep="auto_open=1"><?php $this->input( 'auto_open_delay', __( 'Auto-open delay (seconds)', 'skill-whatsapp-chat-pro' ), 'number', '', 'min="0" max="300"' ); ?></div>
				<?php $this->sw( 'remember_close', __( 'Remember when a visitor closes the popup', 'skill-whatsapp-chat-pro' ), __( 'Prevents auto-open again during the same browser session.', 'skill-whatsapp-chat-pro' ) ); ?>
				<?php $this->input( 'tooltip_delay', __( 'Show tooltip after (seconds, 0 = only on hover)', 'skill-whatsapp-chat-pro' ), 'number', '', 'min="0" max="60"' ); ?>
				<div class="mb-3"><label class="form-label fw-medium" for="f-scroll_trigger"><?php esc_html_e( 'Reveal button after scrolling', 'skill-whatsapp-chat-pro' ); ?> <span class="badge text-bg-light" data-out="scroll_trigger" data-suffix="%"></span></label><input type="range" class="form-range" min="0" max="100" step="5" id="f-scroll_trigger" data-key="scroll_trigger"><div class="form-text"><?php esc_html_e( '0% = always visible.', 'skill-whatsapp-chat-pro' ); ?></div></div>
				<?php $this->sw( 'open_new_tab', __( 'Open WhatsApp in a new tab', 'skill-whatsapp-chat-pro' ) ); ?>
				<?php $this->card_close(); ?>
			</section>

			<!-- DISPLAY -->
			<section class="tab-pane fade" id="tab-display" role="tabpanel">
				<?php $this->card_open( 'funnel', __( 'Where to show', 'skill-whatsapp-chat-pro' ) ); ?>
				<?php $this->select( 'show_on', __( 'Devices', 'skill-whatsapp-chat-pro' ), array( 'all' => __( 'All devices', 'skill-whatsapp-chat-pro' ), 'desktop' => __( 'Desktop only (> 768px)', 'skill-whatsapp-chat-pro' ), 'mobile' => __( 'Mobile & tablet only (≤ 768px)', 'skill-whatsapp-chat-pro' ) ) ); ?>
				<?php $this->select( 'display_rule', __( 'Page rule', 'skill-whatsapp-chat-pro' ), array( 'all' => __( 'Show on every page', 'skill-whatsapp-chat-pro' ), 'include' => __( 'Show ONLY on selected pages', 'skill-whatsapp-chat-pro' ), 'exclude' => __( 'Hide on selected pages', 'skill-whatsapp-chat-pro' ) ) ); ?>
				<div class="swcp-dep" data-dep="display_rule!=all">
					<label class="form-label fw-medium" for="swcp-page-search"><?php esc_html_e( 'Selected pages / posts / products', 'skill-whatsapp-chat-pro' ); ?></label>
					<div class="position-relative mb-2"><div class="input-group"><span class="input-group-text"><i class="bi bi-search"></i></span><input type="search" class="form-control" id="swcp-page-search" placeholder="<?php esc_attr_e( 'Type to search content (AJAX)…', 'skill-whatsapp-chat-pro' ); ?>" autocomplete="off"></div><div class="list-group swcp-suggest shadow d-none" id="swcp-suggest"></div></div>
					<div id="swcp-chips" class="d-flex flex-wrap gap-2 mb-3"></div>
				</div>
				<?php $this->sw( 'hide_logged_in', __( 'Hide for logged-in users', 'skill-whatsapp-chat-pro' ) ); ?>
				<?php $this->sw( 'hide_woo_checkout', __( 'Hide on WooCommerce checkout', 'skill-whatsapp-chat-pro' ), __( 'Reduces distraction during payment.', 'skill-whatsapp-chat-pro' ) ); ?>
				<?php $this->card_close(); ?>
			</section>

			<!-- HOURS -->
			<section class="tab-pane fade" id="tab-hours" role="tabpanel">
				<?php $this->card_open( 'clock-history', __( 'Business hours', 'skill-whatsapp-chat-pro' ), __( 'Show online / offline status automatically', 'skill-whatsapp-chat-pro' ) ); ?>
				<?php $this->sw( 'hours_enabled', __( 'Enable business hours', 'skill-whatsapp-chat-pro' ) ); ?>
				<div class="swcp-dep" data-dep="hours_enabled=1">
					<div class="row"><div class="col-md-6"><div class="mb-3"><label class="form-label fw-medium" for="f-timezone"><?php esc_html_e( 'Timezone', 'skill-whatsapp-chat-pro' ); ?></label><select class="form-select" id="f-timezone" data-key="timezone"><option value=""><?php esc_html_e( 'Use WordPress timezone', 'skill-whatsapp-chat-pro' ); ?></option><?php foreach ( timezone_identifiers_list() as $tz ) echo '<option>' . esc_html( $tz ) . '</option>'; ?></select></div></div>
					<div class="col-md-6"><?php $this->select( 'offline_action', __( 'When offline', 'skill-whatsapp-chat-pro' ), array( 'message' => __( 'Show offline message', 'skill-whatsapp-chat-pro' ), 'hide' => __( 'Hide the widget', 'skill-whatsapp-chat-pro' ) ) ); ?></div></div>
					<div class="table-responsive"><table class="table align-middle swcp-hours"><thead><tr><th><?php esc_html_e( 'Day', 'skill-whatsapp-chat-pro' ); ?></th><th><?php esc_html_e( 'Open', 'skill-whatsapp-chat-pro' ); ?></th><th><?php esc_html_e( 'From', 'skill-whatsapp-chat-pro' ); ?></th><th><?php esc_html_e( 'To', 'skill-whatsapp-chat-pro' ); ?></th></tr></thead><tbody>
					<?php foreach ( $days as $k => $label ) : ?>
						<tr data-day="<?php echo esc_attr( $k ); ?>"><td class="fw-medium"><?php echo esc_html( $label ); ?></td><td><div class="form-check form-switch m-0"><input class="form-check-input" type="checkbox" data-h="on"></div></td><td><input type="time" class="form-control form-control-sm" data-h="from"></td><td><input type="time" class="form-control form-control-sm" data-h="to"></td></tr>
					<?php endforeach; ?>
					</tbody></table></div>
					<button type="button" class="btn btn-sm btn-outline-secondary mb-3 swcp-copy-mon"><i class="bi bi-files"></i> <?php esc_html_e( 'Copy Monday to all weekdays', 'skill-whatsapp-chat-pro' ); ?></button>
					<?php $this->textarea( 'hours_offline_msg', __( 'Offline message', 'skill-whatsapp-chat-pro' ) ); ?>
				</div>
				<?php $this->card_close(); ?>
			</section>

			<!-- PRIVACY -->
			<section class="tab-pane fade" id="tab-privacy" role="tabpanel">
				<?php $this->card_open( 'shield-check', __( 'GDPR consent', 'skill-whatsapp-chat-pro' ) ); ?>
				<?php $this->sw( 'gdpr_enabled', __( 'Require consent checkbox before chatting', 'skill-whatsapp-chat-pro' ) ); ?>
				<div class="swcp-dep" data-dep="gdpr_enabled=1"><?php $this->input( 'gdpr_text', __( 'Consent text', 'skill-whatsapp-chat-pro' ) ); ?></div>
				<?php $this->card_close(); ?>
				<?php $this->card_open( 'graph-up', __( 'Tracking', 'skill-whatsapp-chat-pro' ) ); ?>
				<?php $this->sw( 'analytics_enabled', __( 'Built-in click analytics', 'skill-whatsapp-chat-pro' ), __( 'Aggregate daily counters only. No IPs, no cookies.', 'skill-whatsapp-chat-pro' ) ); ?>
				<?php $this->sw( 'ga4_event', __( 'Send Google Analytics 4 / GTM events', 'skill-whatsapp-chat-pro' ), __( 'Fires whatsapp_click & whatsapp_open via gtag() and dataLayer if present.', 'skill-whatsapp-chat-pro' ) ); ?>
				<?php $this->card_close(); ?>
			</section>

			<!-- ADVANCED -->
			<section class="tab-pane fade" id="tab-advanced" role="tabpanel">
				<?php $this->card_open( 'code-slash', __( 'Shortcode', 'skill-whatsapp-chat-pro' ) ); ?>
				<p class="mb-2"><?php esc_html_e( 'Place an inline WhatsApp button anywhere:', 'skill-whatsapp-chat-pro' ); ?></p>
				<div class="input-group mb-2"><input type="text" class="form-control font-monospace" readonly value='[whatsapp_button text="Chat on WhatsApp" style="pill" align="center"]' id="swcp-sc"><button class="btn btn-outline-success swcp-copy" data-copy="swcp-sc" type="button"><i class="bi bi-clipboard"></i></button></div>
				<small class="text-body-secondary"><?php esc_html_e( 'Attributes: text, phone, msg, style (solid|outline|pill), align (left|center|right).', 'skill-whatsapp-chat-pro' ); ?></small>
				<?php $this->card_close(); ?>
				<?php $this->card_open( 'braces', __( 'Custom CSS', 'skill-whatsapp-chat-pro' ) ); ?>
				<textarea class="form-control font-monospace" rows="6" data-key="custom_css" id="f-custom_css" placeholder=".swcp-btn { box-shadow: none; }"></textarea>
				<?php $this->card_close(); ?>
				<?php $this->card_open( 'tools', __( 'Tools', 'skill-whatsapp-chat-pro' ) ); ?>
				<div class="d-flex flex-wrap gap-2 mb-3">
					<button type="button" class="btn btn-outline-primary swcp-export"><i class="bi bi-download"></i> <?php esc_html_e( 'Export settings', 'skill-whatsapp-chat-pro' ); ?></button>
					<label class="btn btn-outline-primary mb-0"><i class="bi bi-upload"></i> <?php esc_html_e( 'Import settings', 'skill-whatsapp-chat-pro' ); ?><input type="file" accept="application/json,.json" class="d-none swcp-import"></label>
					<button type="button" class="btn btn-outline-warning swcp-clear-stats"><i class="bi bi-eraser"></i> <?php esc_html_e( 'Clear analytics', 'skill-whatsapp-chat-pro' ); ?></button>
					<button type="button" class="btn btn-outline-danger swcp-reset"><i class="bi bi-arrow-counterclockwise"></i> <?php esc_html_e( 'Reset to defaults', 'skill-whatsapp-chat-pro' ); ?></button>
				</div>
				<?php $this->sw( 'delete_on_uninstall', __( 'Delete all plugin data when uninstalling', 'skill-whatsapp-chat-pro' ) ); ?>
				<?php $this->card_close(); ?>
			</section>
		</main>

		<aside class="swcp-preview-col">
			<div class="swcp-preview-sticky">
				<div class="d-flex justify-content-between align-items-center mb-2"><span class="fw-semibold"><i class="bi bi-eye me-1"></i><?php esc_html_e( 'Live preview', 'skill-whatsapp-chat-pro' ); ?></span>
					<div class="btn-group btn-group-sm"><button type="button" class="btn btn-outline-secondary active" data-device="desktop" title="Desktop"><i class="bi bi-laptop"></i></button><button type="button" class="btn btn-outline-secondary" data-device="mobile" title="Mobile"><i class="bi bi-phone"></i></button></div></div>
				<div class="swcp-stage" id="swcp-stage"><div class="swcp-stage-page"><span></span><span></span><span class="w-75"></span><span class="w-50"></span></div><div id="swcp-preview-host"></div></div>
				<small class="text-body-secondary d-block mt-2"><?php esc_html_e( 'Click the button in the preview to toggle the popup.', 'skill-whatsapp-chat-pro' ); ?></small>
			</div>
		</aside>
	</div>

	<div class="toast-container position-fixed bottom-0 end-0 p-3" style="z-index:100000"><div id="swcp-toast" class="toast align-items-center border-0" role="status" aria-live="polite"><div class="d-flex"><div class="toast-body"></div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div></div></div>

	<div class="modal fade" id="swcp-help" tabindex="-1"><div class="modal-dialog modal-dialog-centered modal-lg"><div class="modal-content"><div class="modal-header"><h5 class="modal-title"><i class="bi bi-life-preserver me-2"></i><?php esc_html_e( 'Quick help', 'skill-whatsapp-chat-pro' ); ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body">
		<ol class="mb-0"><li><?php esc_html_e( 'General → enter your WhatsApp number in international format (e.g. 923001234567) and click Test.', 'skill-whatsapp-chat-pro' ); ?></li><li><?php esc_html_e( 'Agents → add team members/departments (optional).', 'skill-whatsapp-chat-pro' ); ?></li><li><?php esc_html_e( 'Design → match colours with your brand; watch the live preview.', 'skill-whatsapp-chat-pro' ); ?></li><li><?php esc_html_e( 'Display Rules & Business Hours → control where and when it shows.', 'skill-whatsapp-chat-pro' ); ?></li><li><?php esc_html_e( 'Click “Save changes” (or press Ctrl/Cmd + S).', 'skill-whatsapp-chat-pro' ); ?></li></ol>
	</div></div></div></div>
</div>
		<?php
	}
}
