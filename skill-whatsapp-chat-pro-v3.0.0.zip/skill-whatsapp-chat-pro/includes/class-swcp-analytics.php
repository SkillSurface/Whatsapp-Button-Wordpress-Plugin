<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Lightweight, privacy-friendly click analytics (no personal data, no cookies).
 * Stores daily aggregate counters in a single non-autoloaded option, 90-day retention.
 */
class SWCP_Analytics {

	public function __construct() {
		add_action( 'wp_ajax_swcp_track', array( $this, 'track' ) );
		add_action( 'wp_ajax_nopriv_swcp_track', array( $this, 'track' ) );
	}

	public function track() {
		check_ajax_referer( 'swcp_track', 'nonce' );
		if ( ! SWCP_Settings::get( 'analytics_enabled' ) ) wp_send_json_success();

		// Basic flood protection per IP hash (10 events / minute).
		$key = 'swcp_rl_' . md5( (string) ( $_SERVER['REMOTE_ADDR'] ?? '' ) . wp_salt() );
		$n   = (int) get_transient( $key );
		if ( $n > 10 ) wp_send_json_error( null, 429 );
		set_transient( $key, $n + 1, MINUTE_IN_SECONDS );

		$event = sanitize_key( $_POST['event'] ?? '' );
		if ( ! in_array( $event, array( 'open', 'click' ), true ) ) wp_send_json_error( null, 400 );
		$agent  = sanitize_key( $_POST['agent'] ?? 'main' );
		$device = ( 'mobile' === sanitize_key( $_POST['device'] ?? '' ) ) ? 'mobile' : 'desktop';

		$stats = (array) get_option( SWCP_STATS, array() );
		$day   = gmdate( 'Y-m-d' );
		$stats[ $day ] = $stats[ $day ] ?? array( 'open' => 0, 'click' => 0, 'mobile' => 0, 'desktop' => 0, 'agents' => array() );
		$stats[ $day ][ $event ]++;
		if ( 'click' === $event ) {
			$stats[ $day ][ $device ]++;
			$stats[ $day ]['agents'][ $agent ] = ( $stats[ $day ]['agents'][ $agent ] ?? 0 ) + 1;
		}
		ksort( $stats );
		$stats = array_slice( $stats, -90, null, true );
		update_option( SWCP_STATS, $stats, false );
		wp_send_json_success();
	}

	public static function summary( $days = 30 ) {
		$stats = (array) get_option( SWCP_STATS, array() );
		$out   = array( 'labels' => array(), 'open' => array(), 'click' => array(), 'total_open' => 0, 'total_click' => 0, 'mobile' => 0, 'desktop' => 0, 'agents' => array() );
		for ( $i = $days - 1; $i >= 0; $i-- ) {
			$d = gmdate( 'Y-m-d', time() - $i * DAY_IN_SECONDS );
			$r = $stats[ $d ] ?? array();
			$out['labels'][] = gmdate( 'M j', strtotime( $d ) );
			$out['open'][]   = (int) ( $r['open'] ?? 0 );
			$out['click'][]  = (int) ( $r['click'] ?? 0 );
			$out['total_open']  += (int) ( $r['open'] ?? 0 );
			$out['total_click'] += (int) ( $r['click'] ?? 0 );
			$out['mobile']  += (int) ( $r['mobile'] ?? 0 );
			$out['desktop'] += (int) ( $r['desktop'] ?? 0 );
			foreach ( (array) ( $r['agents'] ?? array() ) as $a => $c ) $out['agents'][ $a ] = ( $out['agents'][ $a ] ?? 0 ) + (int) $c;
		}
		return $out;
	}
}
